# Guía sencilla para ponerlo en marcha

No necesitas programar. El diseño, el logotipo de Jesuitas Valencia y los colores corporativos ya están incluidos.

## Antes de empezar

- Entra en Google con una cuenta terminada en `@escuelassj.com`.
- Descarga y descomprime este paquete en el ordenador.
- Abre la hoja **Generador de suplencias**:
  <https://docs.google.com/spreadsheets/d/1UaNLLEtzU-fTOA8boGkJwAk7hCQUsgo5NieB8mel_iY/edit>

## 1. Abrir Apps Script

En la hoja de cálculo, pulsa **Extensiones → Apps Script**. Se abrirá una pestaña nueva.

## 2. Copiar `Code.gs`

1. En la columna izquierda, abre el archivo que aparece como `Código.gs` o `Code.gs`.
2. Borra todo lo que contiene.
3. Abre el archivo `Code.gs` de este paquete con un editor de texto.
4. Copia todo su contenido y pégalo en Apps Script.

## 3. Crear y copiar `Index.html`

1. En Apps Script, pulsa el signo **+** situado junto a **Archivos**.
2. Elige **HTML**.
3. Escribe exactamente `Index` como nombre y pulsa Intro.
4. Borra el contenido que aparezca.
5. Abre `Index.html` de este paquete, copia todo y pégalo en Apps Script.

No subas el archivo del logotipo: ya está incorporado dentro de `Index.html`.

## 4. Copiar `appsscript.json`

1. Pulsa **Configuración del proyecto** —el icono de rueda dentada de la izquierda—.
2. Activa **Mostrar el archivo de manifiesto `appsscript.json` en el editor**.
3. Vuelve al editor y abre `appsscript.json`.
4. Borra su contenido.
5. Abre el `appsscript.json` de este paquete, copia todo y pégalo en Apps Script.
6. Pulsa **Guardar proyecto**.

## 5. Comprobar y autorizar

1. En el desplegable de funciones de la barra superior, selecciona `runSelfCheck`.
2. Pulsa **Ejecutar**.
3. Google pedirá autorización la primera vez. Elige tu cuenta corporativa y acepta los permisos.
4. La ejecución debe terminar sin errores.

Esta comprobación no modifica la hoja, no crea eventos y no envía correos.

## 6. Publicar y obtener el enlace

1. Pulsa **Implementar → Nueva implementación**.
2. Junto a **Seleccionar tipo**, pulsa la rueda dentada y elige **Aplicación web**.
3. En **Ejecutar como**, selecciona **Usuario que accede a la aplicación web**.
4. En **Quién tiene acceso**, elige la opción limitada a tu organización o dominio.
5. Pulsa **Implementar** y acepta los permisos que solicite Google.
6. Copia la URL que termina en `/exec`.

Esa URL es el enlace que debes compartir con las personas autorizadas de `@escuelassj.com`.

## Importante sobre el acceso

No elijas **Cualquier usuario**. Si no aparece una opción para limitar el acceso a la organización, el administrador de Google Workspace de `escuelassj.com` tendrá que habilitarla o realizar la publicación.

Las personas que vayan a registrar suplencias también necesitan permiso de edición en la hoja de cálculo.

## Cuando cambies algo más adelante

Para conservar el mismo enlace, ve a **Implementar → Gestionar implementaciones**, edita la implementación, elige **Nueva versión** y vuelve a implementar.
